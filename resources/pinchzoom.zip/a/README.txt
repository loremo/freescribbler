Demo:  
Git Repo: https://bitbucket.org/nilsdehl/sencha-touch-2-path-like-menu/
Blogpost: http://www.nils-dehl.de/2012/04/path-like-menu-for-senchatouch-2/

by 

Nils Dehl

w: http://nils-dehl.de
t: nilsdehl
m: mail(at)nils-dehl.de
describe('jasmine-node-flat', function() {
    it('should pass', function() {
        expect(1 + 2).toEqual(3);
    });

    it("should be ok", function() {
        expect(Ext);
    });
});

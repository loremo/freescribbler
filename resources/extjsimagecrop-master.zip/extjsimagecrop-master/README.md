extjsimagecrop
==============

Contains the ExtJS UX Image Crop Utility

For Usage see: http://www.thomas-lauria.de/extamples/image_crop.html

For Issues use the Git Issue Tracker: https://github.com/thomaslauria/extjsimagecrop/issues

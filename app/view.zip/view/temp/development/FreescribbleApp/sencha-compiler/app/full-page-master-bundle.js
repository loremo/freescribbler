// @tag full-page
// @require /Users/hancock/Sites/freescribble/app.js
